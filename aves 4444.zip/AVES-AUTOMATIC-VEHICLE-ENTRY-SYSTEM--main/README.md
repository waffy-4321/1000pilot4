# AVES-AUTOMATIC-VEHICLE-ENTRY-SYSTEM-
Video Demo < https://youtu.be/2-64yEK0doE >
 Description 
 Hello Humans,
Today, many people visit offices, malls, societies, etc., and before entering they must manually enter their data. Sometimes, people forget to do this, and as a result, they are marked absent. To solve this issue, I created this application so that when any vehicle enters the office building, it will scan the car plate number and his entry can be done automatically. I'm tell you some tips which are helps to run this project in your system:
I'm tell you some tips which are helps to run this project in your system:
1. Create some folders like: Capture_image, Cropped_image 
2. Change paths according to your system
3. Run On Visual Studio Code
4. Check SCREENSHOTS for better understanding
5. Create Database AVES and create 2 tables : MASTERTABLE, TRANSACTIONTABLE
6. Install some libraries like: OPENCV, MATPLOTLIB, PYQT5, PYTESSARCT, MYSQL CONNECTOR, NUMPY, IMUTILS, etc.
Now Enjoy!!
